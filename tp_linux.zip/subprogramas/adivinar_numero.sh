#!/usr/bin/bash

#Ingresar aqui el codigo que adivina numeros.

echo "Falta programar"