#Trabajo practico de linux.

Ejecutar inicio.sh para comenzar con el menu inicial.
La carpeta subprograma contiene distintos scripts que va a ir lanzando el programa inicial inicio.sh